for a in range(1,10):
  for b in range(1,10):
    print '%sx%s=%s' % (a,b,a*b)