for x in xrange(1,10):
    for y in xrange(1,10):
        print "%dx%d=%d"%(x,y,x*y)