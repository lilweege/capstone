for i in range(1,10):
    for s in range(1,10):
        print str(i)+"x"+str(s)+"="+str(i*s)