A=range(1,10)
for i in A:
  for j in A:
    print"%dx%d=%d"%(i,j,i*j)