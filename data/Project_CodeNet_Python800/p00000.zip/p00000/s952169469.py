#!/usr/bin/env python3
#coding: utf-8

for x in range(1,10):
    for y in range(1,10):
        print("{0}x{1}={2}".format(x, y, x*y))