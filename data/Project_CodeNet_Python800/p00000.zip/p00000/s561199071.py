for i in xrange(1,10):
    for n in xrange(1,10):
        print("%dx%d=%d" % (i, n, i * n))