for i in range(1,10):
    a = i
    for j in range(1,10):
        b = j
        c = a*b
    
        print('%dx%d=%d' %(a,b,c))
    
