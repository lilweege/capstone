for i in range(9):
    for j in range(9):
        print(i+1,end="")
        print("x",end="")
        print(j+1,end="")
        print("=",end="")
        print((i+1)*(j+1))
        
