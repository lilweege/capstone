for i in [1,2,3,4,5,6,7,8,9]:
    for j in [1,2,3,4,5,6,7,8,9]:
       print '%sx%s=%s' % (i,j,i*j)