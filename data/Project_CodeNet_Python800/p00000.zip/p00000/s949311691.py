for n in range(1,10):
 for m in range(1,10):
  print("{}x{}={}".format(n,m,n*m))
