# -*- coding: utf-8 -*-

for i in range(1,10):
	for j in range(1,10):
		print(i,end = "x")
		print(j,end = "=")
		print(i*j)