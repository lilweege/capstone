kuk = range(1, 10)
for i in kuk:
	for j in kuk:
		print '%dx%d=%d' % (i, j, i*j)