[print(str(i)+"x"+str(j)+"="+str(i*j))for i in range(1,10)for j in range(1,10)]
