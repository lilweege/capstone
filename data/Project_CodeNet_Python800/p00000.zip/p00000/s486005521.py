for j in range(1,10):
    for k in range(1,10):
        print str(j)+"x"+str(k)+"="+str(j*k)