x=range(1,10)
[print("%dx%d=%d"%(i,j,i*j))for i in x for j in x]