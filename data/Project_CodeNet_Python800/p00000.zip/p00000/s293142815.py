x = range(1, 10)
y = range(1, 10)

for i in x:
    for j in y:
        print(str(i)+'x'+str(j)+'='+str(i*j))

