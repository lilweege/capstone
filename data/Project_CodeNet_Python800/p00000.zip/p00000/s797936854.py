# -*- coding: utf-8 -*-
"""
http://judge.u-aizu.ac.jp/onlinejudge/description.jsp?id=0000&lang=jp

QQ
"""

if __name__ == '__main__':
    # ???????????????
    for i in range(1, 10):
        for j in range(1, 10):
            print('{0}x{1}={2}'.format(i, j, i*j))