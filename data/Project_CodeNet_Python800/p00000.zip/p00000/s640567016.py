a = 1
b = 1
for count in range(9):
    for count in range(9):
        print(str(a) + 'x' + str(b) + '=' + str(a * b))
        b += 1
    a += 1
    b = 1



