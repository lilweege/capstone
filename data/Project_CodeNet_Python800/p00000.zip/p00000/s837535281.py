for A in range(1, 10):
  for B in range(1, 10):
    print str(A) + 'x' + str(B) + '=' + str(A * B)