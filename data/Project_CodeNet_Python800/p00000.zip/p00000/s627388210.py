x=int(1)
for var in range(1,10):
    y=int(1)
    for var in range(1,10):
        print("{}x{}={}".format(x,y,x*y))
        y+=1
    x+=1