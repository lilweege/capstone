for k in range(1,10):
    for j in range(1,10):
        k,j = map(int,(k,j))
        kj = k * j
        
        kj = str(kj)
        k = str(k)
        j = str(j)
        
        print k + "x" + j + "=" + kj