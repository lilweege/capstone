for i in range(1,10):
    for j in range(1,10):
        print('{l}x{r}={result}'.format(l=i,r=j,result=i*j))