for i in range(1,10):
    for j in range(1,10):
        ans=i*j
        print(f'{i}x{j}={ans}')
