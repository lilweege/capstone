list1 = range(1,10)
list2 = list1
for i in list1 :
    for j in list2 :
        print str(i) + "x" + str(j) + "=" + str(i*j)