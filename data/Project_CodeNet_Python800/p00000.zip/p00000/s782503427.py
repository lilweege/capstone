for a in range(1,10):
    for b in range(1,10):
        print('{0}x{1}={2}'.format(a,b,a*b))