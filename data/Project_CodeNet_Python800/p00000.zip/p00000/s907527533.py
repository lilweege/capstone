def main():
    for a in range(1,10):
        for b in range(1,10):
            print("{}x{}={}".format(a,b,a*b))
    return None

if __name__ == '__main__':
    main()