a=1
b=1

while a<10:
    while b<10:
        c=a*b
        print(str(a)+"x"+str(b)+"="+str(c))
        b+=1
    a+=1
    b=1
