for i in range(10):
    for j in range(10):
        if(i > 0 and j > 0):
            print(str(i) + 'x' + str(j) + '=' + str(i*j))