for i in range(10):
    for a in range(10):
        if (i == 0 or a == 0):
            pass
        else:
            print (i,'x',a,'=',i * a,sep='')
