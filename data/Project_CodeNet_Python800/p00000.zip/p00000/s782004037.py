# -*- coding: utf-8 -*-

if __name__ == '__main__':
	for dan1 in xrange(1, 10):
		for dan2 in xrange(1, 10):
			print str(dan1) + "x" + str(dan2) + "=" + str(dan1*dan2)