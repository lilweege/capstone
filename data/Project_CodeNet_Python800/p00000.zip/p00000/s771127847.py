for a in range(1,10):
    for b in range(1,10):
        ans=a*b
        print(str(a)+"x"+str(b)+"="+str(ans))