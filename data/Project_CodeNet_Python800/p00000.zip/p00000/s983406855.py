i=1

while i<=9:
    j=1
    while j<=9:
        print(i, "x", j, "=", i*j, sep="")
        j+=1
    i+=1
