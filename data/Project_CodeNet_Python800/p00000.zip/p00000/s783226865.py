a=1; b=1; c=0
while a<10:
    while b<10:
        c=a*b
        print("%dx%d=%d" %(a,b,c))
        b+=1
    a+=1;b=1