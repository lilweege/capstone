#!/usr/bin/python
#-coding:utf8-

for i in range(10)[1:]:
  for j in range(10)[1:]:
    print "%dx%d=%d" % ( i,j,i*j )