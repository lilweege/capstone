#encoding=utf-8

for i in xrange(9):
    for j in xrange(9):
        ans = (i + 1)*(j + 1)
        print str(i + 1) + "x" + str(j + 1) + "=" + str((i + 1)*(j + 1)) 