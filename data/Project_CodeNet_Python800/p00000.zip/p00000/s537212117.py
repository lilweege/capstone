for a in range(1,10):
    for b in range(1,10):
        ans = a*b
        print(f'{a}x{b}={ans}')
