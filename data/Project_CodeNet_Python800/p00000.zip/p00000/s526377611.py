for i in range(1,10):
	for j in range(1,10):
		multiply = i * j
		print('{0}x{1}={2}'.format(i,j,multiply))