j=1
while j < 10:
    
    i=1
    while i < 10:
        print(j,end="")
        print('x',end="")
        print(i,end="")
        print('=',end="")
        print(j*i)
        i=i+1
    
    j=j+1
