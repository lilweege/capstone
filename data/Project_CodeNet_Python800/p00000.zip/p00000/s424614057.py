for i in range(9):
    for j in range(9):
        print("{}x{}={}".format(i+1,j+1,(i+1)*(j+1)))
