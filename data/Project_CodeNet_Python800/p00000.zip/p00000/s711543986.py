for pre in range(1, 10):
    for post in range(1, 10):
        print('{}x{}={}'.format(pre, post, pre * post))