for i in range(1,10):
    for k in range(1,10):
        ans = i*k
        print(str(i)+"x"+str(k)+"="+str(ans))
