i = 0
for t in range(1, 10):
        for j in range(1, 10):
            i = t * j
            print(f"{t}x{j}={i}")


