for y in xrange(1, 10):
    for x in xrange(1, 10):
        print('%dx%d=%d' % (y, x, y*x))