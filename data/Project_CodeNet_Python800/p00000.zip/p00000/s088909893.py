for i in range(1,10):
    for j in range(1,10):
        print('%sx%s=%s'%(i,j,i*j))