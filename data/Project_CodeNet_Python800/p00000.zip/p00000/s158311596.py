for x in range(1,10):
    for y in range(1,10):
        print "%dx%d=%d" % (x,y,x*y)