for x in xrange(9):
	for y in xrange(9):
		print str(x + 1) + "x" + str(y + 1) + "=" + str((x + 1) * (y + 1))