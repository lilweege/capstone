l = [i for i in range(1,10)]
for i in l:
  for j in l:
    print(str(i)+ 'x' + str(j) + '=' + str(i*j))