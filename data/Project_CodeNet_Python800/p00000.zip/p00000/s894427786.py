for a in range(9):
    for i in range(9):
       print(a+1,'x',(i+1),"=",(i+1)*(a+1), sep='')
