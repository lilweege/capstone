for i in range(1,10):
    for j in range(1,10):
        s = i * j
        print("{0}{3}{1}={2}".format(i, j, s, "x"))