#coding:utf-8

for i in xrange(1, 10):
    for n in xrange(1, 10):
        print("{0}x{1}={2}". format(i, n, i * n))