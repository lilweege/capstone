i=1
while i<10 :
    k=1
    while k<10 :
        print("%dx%d=%d"%(i,k,i*k))
        k=k+1
    i=i+1
