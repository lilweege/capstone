for i in range(9):
    for k in range(9):
        p = (i+1)*(k+1)
        print('{}x{}={}'.format(i+1,k+1,p))
