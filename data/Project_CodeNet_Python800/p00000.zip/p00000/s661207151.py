for k in range(1,10):
    for i in range(1,10):
        s=k*i
        print(f"{k}x{i}={s}")
