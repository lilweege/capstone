i=1
for i in range(9):
    i+=1
    print(f'1x{i}={1*i}')
for i in range(9):
    i+=1
    print(f'2x{i}={2*i}')
for i in range(9):
    i+=1
    print(f'3x{i}={3*i}')    
for i in range(9):
    i+=1
    print(f'4x{i}={4*i}')    
for i in range(9):
    i+=1
    print(f'5x{i}={5*i}')    
for i in range(9):
    i+=1
    print(f'6x{i}={6*i}')
for i in range(9):
    i+=1
    print(f'7x{i}={7*i}')
for i in range(9):
    i+=1
    print(f'8x{i}={8*i}')   
for i in range(9):
    i+=1
    print(f'9x{i}={9*i}')   
