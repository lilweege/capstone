for a in range(1,10):
    for b in range(1,10):
        ans=str(a*b)
        print(str(a)+'x'+str(b)+'='+ans)
