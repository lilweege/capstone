kukuo=[i+1 for i in range(9)]
for i in kukuo:
     for e in kukuo:
         print("%ix%i=%i"%(i,e,i*e))