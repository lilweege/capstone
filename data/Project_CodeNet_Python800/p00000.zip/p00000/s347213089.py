for i in range(1,10):
    for k in range(1,10):
        print("{0}x{1}={2}".format(i,k,i*k))