for i in range (9):
    for j in range(9):
        i=i+1
        j=j+1
        k=i*j
        print(str(i)+"x"+str(j)+"="+str(k))
        i=i-1
        j=j-1