for num1 in range(1, 10):
    for num2 in range(1, 10):
        result = num1 * num2
        print("{0}x{1}={2}".format(num1, num2, result))