for i in range(1,10):
    for j in range (1,10):
        A=i*j
        print(i,"x",j,"=",A,sep="")
