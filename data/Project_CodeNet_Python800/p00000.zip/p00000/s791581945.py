for i in range(9):
	for j in range(9):
		print str(i+1)+"x"+str(j+1)+"="+str((i+1)*(j+1))