# Vol0000.
import sys

def main():
    for i in range(1, 10):
        for k in range(1, 10):
            print(str(i) + "x" + str(k) + "=" + str(i * k))

if __name__ == "__main__":
    main()

