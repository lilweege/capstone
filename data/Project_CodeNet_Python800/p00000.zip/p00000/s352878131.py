for i in range(0,9):
    for j in range(0,9):
        print("{0}x{1}={2}".format(i+1,j+1,(i+1)*(j+1)))