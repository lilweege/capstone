for x in range(1, 10):
    for y in range(1, 10):
        print("{a}x{b}={c}".format(a=x, b=y, c=x*y))

