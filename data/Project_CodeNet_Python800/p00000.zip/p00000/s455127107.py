for i in xrange(1,10):
    for j in xrange(1,10):
        print '%sx%s=%s'%(i,j,i*j)