i=1
n=1
while n<10:
    for i in range(1,10):
        y=i*n
        print(f'{n}x{i}={y}')
    n+=1  
