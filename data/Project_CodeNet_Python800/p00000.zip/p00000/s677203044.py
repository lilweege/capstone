for i in range (9):
    for j in range (9):
        p=i+1
        q=j+1
        ans=p*q
        QQ=str(p)+"x"+str(q)+"="+str(ans)
        print QQ