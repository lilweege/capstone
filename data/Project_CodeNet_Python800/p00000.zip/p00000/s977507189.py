for x in range(9):
    for y in range(9):
        print("%dx%d=%d" % (x+1,y+1,(x+1)*(y+1)))