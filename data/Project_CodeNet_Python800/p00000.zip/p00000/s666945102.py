x=[1,2,3,4,5,6,7,8,9]
for i in x:
    for j in x:
        print u"%dx%d=%d"%(i,j,i*j)