a=1
for i in range(9):
    b = 1
    for e in range(9):
        c=a*b
        print(str(a)+"x"+str(b)+"="+str(c))
        b = b + 1
    a=a+1
