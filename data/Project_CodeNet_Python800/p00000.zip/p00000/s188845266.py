def main():

    for N in range(1,10):
        for M in range(1,10):
            print(str(N)+"x"+str(M)+"="+str(N*M))


if __name__ == '__main__':
    main()