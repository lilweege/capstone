for i in range(1,10):
    for t in range(1,10):
        print(f'{i}x{t}={i*t}')
