number = {1,2,3,4,5,6,7,8,9}
for a in number:
    for b in number:
        print(str(a)+"x"+str(b)+"="+str(a * b))